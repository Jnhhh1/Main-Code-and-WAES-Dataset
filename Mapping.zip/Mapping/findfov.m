
clear; clc;

load('matlab.mat');
indices = [4119, 6313, 6384, 6453]; 
values = Fov1(indices);      

disp(values);
