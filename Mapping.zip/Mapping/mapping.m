clear all; clc; tic;


load('FOV.mat');


load('T.mat');
T=inv_T;


Fov_new = swapComplexParts(Fov1);


half_side = 0.009;


num_points = length(Fov_new);  % 11773

fprintf('The number of length(Fov_new): %d\n', num_points);


Fov_vertices = zeros(4, num_points);


for i = 1:num_points
   
    z = Fov_new(i);
    a = real(z);  
    b = imag(z);  
    
    
    Fov_vertices(1, i) = (a - half_side) + 1i*(b - half_side);  
    Fov_vertices(2, i) = (a + half_side) + 1i*(b - half_side);  
    Fov_vertices(3, i) = (a + half_side) + 1i*(b + half_side);  
    Fov_vertices(4, i) = (a - half_side) + 1i*(b + half_side);  
end


az_vertices = zeros(4, num_points);  
el_vertices = zeros(4, num_points);  


for i = 1:num_points
    for j = 1:4
        
        z_vertex = Fov_vertices(j, i);
        
        
        [az, el] = complexToAngles(z_vertex);
        
        
        az_vertices(j, i) = az;
        el_vertices(j, i) = el;
    end
end




wgs84.a = 6378137.0;            
wgs84.f = 1/298.257223563;      
wgs84.b = wgs84.a * (1 - wgs84.f);  
wgs84.e2 = 2*wgs84.f - wgs84.f^2;  
wgs84.omega = 7.292115e-5;      


sat.lon = 63.2612;      
sat.lat = 41.5068;       
sat.alt = 860774.5002196059;     


lon_vertices = zeros(4, num_points);  
lat_vertices = zeros(4, num_points);  


for i = 1:num_points
    for j = 1:4
        
        azimuth = az_vertices(j, i);
        elevation = el_vertices(j, i)-90;
        
        deg2rad = pi/180;
        rad2deg = 180/pi;
        
        sat.lon_rad = sat.lon * deg2rad;
        sat.lat_rad = sat.lat * deg2rad;
        azimuth_rad = azimuth * deg2rad;
        elevation_rad = elevation * deg2rad;
        
        
        N = wgs84.a / sqrt(1 - wgs84.e2 * sin(sat.lat_rad)^2);
        
      
        sat.x = (N + sat.alt) * cos(sat.lat_rad) * cos(sat.lon_rad);
        sat.y = (N + sat.alt) * cos(sat.lat_rad) * sin(sat.lon_rad); 
        sat.z = (N * (1 - wgs84.e2) + sat.alt) * sin(sat.lat_rad);
        
        
        V_north = cos(elevation_rad) * cos(azimuth_rad);
        V_east  = cos(elevation_rad) * sin(azimuth_rad);
        V_down  = -sin(elevation_rad);  
        
        V_ned = [V_north; V_east; V_down];
        
       
        norm_V = norm(V_ned);
        
       
        
        R_ecef2ned = zeros(3,3);
        R_ecef2ned(1,1) = -sin(sat.lat_rad) * cos(sat.lon_rad);
        R_ecef2ned(1,2) = -sin(sat.lat_rad) * sin(sat.lon_rad);
        R_ecef2ned(1,3) =  cos(sat.lat_rad);
        
        R_ecef2ned(2,1) = -sin(sat.lon_rad);
        R_ecef2ned(2,2) =  cos(sat.lon_rad);
        R_ecef2ned(2,3) =  0;
        
        R_ecef2ned(3,1) = -cos(sat.lat_rad) * cos(sat.lon_rad);
        R_ecef2ned(3,2) = -cos(sat.lat_rad) * sin(sat.lon_rad);
        R_ecef2ned(3,3) = -sin(sat.lat_rad);
       
        R_ned2ecef = R_ecef2ned';  
      
        V_ecef = R_ned2ecef * V_ned;
       
        a2 = wgs84.a^2;
        b2 = wgs84.b^2;
        
        A = (V_ecef(1)^2 + V_ecef(2)^2)/a2 + V_ecef(3)^2/b2;
        B = 2 * ((sat.x*V_ecef(1) + sat.y*V_ecef(2))/a2 + sat.z*V_ecef(3)/b2);
        C = (sat.x^2 + sat.y^2)/a2 + sat.z^2/b2 - 1;
        
        
       
        discriminant = B^2 - 4*A*C;
        
        t1 = (-B + sqrt(discriminant)) / (2*A);
        t2 = (-B - sqrt(discriminant)) / (2*A);
        
        
       
        if t1 > 0 && t2 > 0
            t_intersect = min(t1, t2); 
        elseif t1 > 0
            t_intersect = t1;
        elseif t2 > 0
            t_intersect = t2;
        end
        
        
        
        target.x = sat.x + t_intersect * V_ecef(1);
        target.y = sat.y + t_intersect * V_ecef(2);
        target.z = sat.z + t_intersect * V_ecef(3);
        
        
        
        target.lon_rad = atan2(target.y, target.x);
        target.lon = target.lon_rad * rad2deg;
        
        
        p = sqrt(target.x^2 + target.y^2);
        lat_old = atan2(target.z, p * (1 - wgs84.e2));  
        
        
        max_iter = 10;
        tol = 1e-12;
        
        for iter = 1:max_iter
            N = wgs84.a / sqrt(1 - wgs84.e2 * sin(lat_old)^2);
            h = p / cos(lat_old) - N;
            lat_new = atan2(target.z, p * (1 - wgs84.e2 * N/(N + h)));
            
            if abs(lat_new - lat_old) < tol
                break;
            end
            lat_old = lat_new;
        end
        
        target.lat_rad = lat_new;
        target.lat = target.lat_rad * rad2deg;
        
        
        target.h = p / cos(target.lat_rad) - N;
        
        lon_vertices(j, i) = target.lon;
        lat_vertices(j, i) = target.lat;
    end
end


fprintf('\n========== Prepare the drawing ==========\n');


[num_vertices_per_point, num_points] = size(lon_vertices);  % num_vertices_per_point = 4, num_points = 11773
fprintf('Raw data size: lon_vertices %d×%d, lat_vertices %d×%d\n', ...
    size(lon_vertices,1), size(lon_vertices,2), size(lat_vertices,1), size(lat_vertices,2));


X_all = zeros(num_points, 4);  % 11773 × 4
Y_all = zeros(num_points, 4);  % 11773 × 4


for i = 1:num_points
    
    X_all(i, :) = lon_vertices(:, i)';  
    Y_all(i, :) = lat_vertices(:, i)';  
end

fprintf('Reconstructed data size: X_all %d×%d, Y_all %d×%d\n', ...
    size(X_all,1), size(X_all,2), size(Y_all,1), size(Y_all,2));


if size(T, 1) == 1
    T = T';  
end
fprintf('T data size: %d×%d\n', size(T,1), size(T,2));


valid_squares = all(~isnan(X_all), 2) & all(~isnan(Y_all), 2);
fprintf('Number of effective squares: %d/%d\n', sum(valid_squares), num_points);


if sum(valid_squares) < num_points
    X_all_filtered = X_all(valid_squares, :);
    Y_all_filtered = Y_all(valid_squares, :);
    T_filtered = T(valid_squares);
else
    X_all_filtered = X_all;
    Y_all_filtered = Y_all;
    T_filtered = T;
end


fprintf('\n========== Mapping brightness temperature distribution ==========\n');

figure('Position', [100, 100, 1200, 900]);


hold on;
colormap jet;

num_valid = size(X_all_filtered, 1);

for i = 1:num_valid
   
    fill(X_all_filtered(i,:), Y_all_filtered(i,:), T_filtered(i), ...
        'linestyle', 'none');
    
   
    
end
fprintf('Finish！\n');


xlabel('Longitude (°)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Latitude (°)', 'FontSize', 14, 'FontWeight', 'bold');

c = colorbar;
c.Label.String = 'Brightness Temperature [K]';
c.Label.FontSize = 12;


axis equal;
grid on;
box on;


lon_min = min(X_all_filtered(:));
lon_max = max(X_all_filtered(:));
lat_min = min(Y_all_filtered(:));
lat_max = max(Y_all_filtered(:));


lon_range = lon_max - lon_min;
lat_range = lat_max - lat_min;
margin_lon = lon_range * 0.02;
margin_lat = lat_range * 0.02;

xlim([lon_min - margin_lon, lon_max + margin_lon]);
ylim([lat_min - margin_lat, lat_max + margin_lat]);


figure;
lon_vec = lon_vertices(:);
lat_vec = lat_vertices(:);
valid_idx = ~isnan(lon_vec) & ~isnan(lat_vec);
plot(lon_vec(valid_idx), lat_vec(valid_idx), 'b.', 'MarkerSize', 2);
xlabel('Longitude (°)');
ylabel('Latitude (°)');

grid on;
axis equal;


figure;
histogram(T_filtered, 30);
xlabel('Brightness Temperature [K]');
ylabel('Frequency');
grid on;


save('plot_data.mat', 'X_all', 'Y_all', 'T', 'lon_vertices', 'lat_vertices');



function z_new = swapComplexParts(z)




z_new = imag(z) + 1i * real(z);



end

function [p, q] = complexToAngles(z)

sz = size(z);


p = zeros(sz);
q = zeros(sz);


a = real(z);  % a = sin(q)*sin(p)
b = imag(z);  % b = sin(q)*cos(p)


for i = 1:numel(z)
    ai = a(i);
    bi = b(i);
    
    % sin(q)
    sin_q = sqrt(ai^2 + bi^2);
    
   
    if sin_q > 1
        sin_q = 1;
    elseif sin_q < 0
        sin_q = 0;
    end
    
    % q (0-90°)
    q(i) = asind(sin_q);
    
    if abs(ai) < eps && abs(bi) < eps
        
        p(i) = 0;
    elseif abs(ai) < eps
        
        if bi > 0
            p(i) = 0;  % cos(p)=1, p=0°
        else
            p(i) = 180;  % cos(p)=-1, p=180°
        end
    elseif abs(bi) < eps
        
        if ai > 0
            p(i) = 90;  % sin(p)=1, p=90°
        else
            p(i) = 270;  % sin(p)=-1, p=270°
        end
    else
       
        p_rad = atan2(ai, bi);
        
       
        p_deg = p_rad * 180 / pi;
        
       
        if p_deg < 0
            p_deg = p_deg + 360;
        end
        
        
        p(i) = p_deg;
        
    
    end
   
end

end