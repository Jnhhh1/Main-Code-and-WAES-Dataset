clear all; clc; tic;

load('T.mat');

indices = find(inv_T > 700);

disp(indices);

disp(inv_T(indices));
